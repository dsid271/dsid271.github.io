import React from 'react';
import { Github, Linkedin, Mail } from 'lucide-react';

export function Header() {
  return (
    <header className="bg-gradient-to-r from-blue-900 to-purple-900 text-white py-6">
      <nav className="container mx-auto px-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold">Rahul Kumar</h1>
        <div className="flex gap-4">
          <a href="https://github.com/yourusername" className="hover:text-blue-300 transition-colors">
            <Github size={24} />
          </a>
          <a href="https://linkedin.com/in/yourusername" className="hover:text-blue-300 transition-colors">
            <Linkedin size={24} />
          </a>
          <a href="mailto:your.email@example.com" className="hover:text-blue-300 transition-colors">
            <Mail size={24} />
          </a>
        </div>
      </nav>
    </header>
  );
}